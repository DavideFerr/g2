// Operazioni.cpp : definisce il punto di ingresso dell'applicazione console.
//

#include "stdafx.h"


int main()
{
    return 0;
}

