class ProvaOperazioni
{
public:
	ProvaOperazioni();
	~ProvaOperazioni();

	int Somma(int num1, int num2);
	int Differenza(int num1, int num2);
	int Moltiplicazione(int num1, int num2);
	int Divisione(int num1, int num2);
	float RadiceQuadrata(float num1);
};
