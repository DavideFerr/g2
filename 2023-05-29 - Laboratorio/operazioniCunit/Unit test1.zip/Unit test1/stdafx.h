// stdafx.h : file di inclusione per file di sistema standard,
// o file di inclusione specifici del progetto utilizzati di frequente, ma
// modificati raramente
//

#pragma once

#include "targetver.h"

// Intestazioni per CppUnitTest
#include "CppUnitTest.h"

// TODO: fare riferimento qui alle intestazioni aggiuntive richieste dal programma
